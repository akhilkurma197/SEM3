/**
 * Trust Layer - Universal Link, Shadow DOM, Button, & Typosquatting Detector
 * Enhanced Brand Impersonation (+6.5 Logit = 96%+ Phishing Alert) & Guaranteed 2% Official Domain Pass.
 */

// Memory Cache to ensure 0ms latency on repeated hovers
const linkCache = new Map();
let hoverTimer = null;
let currentTooltip = null;
let lastHoveredUrl = null;

// Expanded Global Trusted Domain Whitelist
const TRUSTED_DOMAINS = [
  'google.com', 'google.co.in', 'gstatic.com', 'googleusercontent.com', 'youtube.com',
  'chatgpt.com', 'openai.com', 'oaistatic.com', 'oaiusercontent.com',
  'github.com', 'githubusercontent.com', 'leetcode.com', 'wikipedia.org',
  'microsoft.com', 'live.com', 'office.com', 'apple.com', 'icloud.com',
  'linkedin.com', 'twitter.com', 'x.com', 'reddit.com', 'stackoverflow.com',
  'amazon.com', 'amazon.in', 'flipkart.com', 'netflix.com', 'paypal.com',
  'hdfcbank.com', 'icicibank.com', 'sbi.co.in', 'onlinesbi.sbi', 'paytm.com', 'phonepe.com'
];

const BRAND_WHITELIST = [
  { name: 'ChatGPT / OpenAI', domains: ['chatgpt.com', 'openai.com'], keywords: ['chatgpt', 'openai'] },
  { name: 'HDFC Bank', domains: ['hdfcbank.com', 'hdfc.com', 'netbanking.hdfcbank.com'], keywords: ['hdfc', 'netbanking'] },
  { name: 'ICICI Bank', domains: ['icicibank.com', 'icicibank.co.in'], keywords: ['icici', 'imobile'] },
  { name: 'State Bank of India (SBI)', domains: ['sbi.co.in', 'onlinesbi.sbi', 'onlinesbi.com'], keywords: ['sbi', 'onlinesbi', 'yono'] },
  { name: 'Axis Bank', domains: ['axisbank.com'], keywords: ['axis', 'axisbank'] },
  { name: 'Paytm', domains: ['paytm.com', 'paytmbank.com'], keywords: ['paytm', 'paytmbank'] },
  { name: 'PhonePe', domains: ['phonepe.com'], keywords: ['phonepe'] },
  { name: 'Google Pay / Google', domains: ['pay.google.com', 'google.com', 'accounts.google.com'], keywords: ['gpay', 'googlepay', 'google'] },
  { name: 'Amazon', domains: ['amazon.in', 'amazon.com', 'pay.amazon.in'], keywords: ['amazon', 'amazonpay'] },
  { name: 'GitHub', domains: ['github.com'], keywords: ['github'] },
  { name: 'LeetCode', domains: ['leetcode.com'], keywords: ['leetcode'] },
  { name: 'PayPal', domains: ['paypal.com', 'paypal.me'], keywords: ['paypal'] }
];

const SUSPICIOUS_TLDS = ['.xyz', '.top', '.tk', '.ml', '.ga', '.cf', '.gq', '.work', '.click', '.monster', '.fit', '.icu', '.loan', '.vip', '.rest'];
const HOMOGLYPH_MAP = { 'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x', 'і': 'i', 'ј': 'j', 'ѕ': 's', 'ԁ': 'd' };
const SENSITIVE_KEYWORDS = ['login', 'signin', 'verify', 'update', 'banking', 'secure', 'account', 'kyc', 'otp', 'pin', 'payment', 'claim'];

/**
 * Levenshtein distance for typosquatting detection (e.g. chattgpt.com vs chatgpt.com)
 */
function levenshteinDistance(a, b) {
  const matrix = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
  for (let j = 0; j <= b.length; j++) matrix[0][j] = j;

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  return matrix[a.length][b.length];
}

function extractTargetUrlFromEvent(e) {
  const path = e.composedPath ? e.composedPath() : [e.target];
  if (!path || !path.length) return null;

  for (let el of path) {
    if (!el || el.nodeType !== 1) continue;

    const url = checkElementForUrl(el);
    if (url) return url;
  }

  return null;
}

function checkElementForUrl(current) {
  if (current.href && typeof current.href === 'string') {
    const res = sanitizeAndResolveUrl(current.href);
    if (res) return res;
  }
  const rawHref = current.getAttribute && current.getAttribute('href');
  if (rawHref) {
    const res = sanitizeAndResolveUrl(rawHref);
    if (res) return res;
  }

  if (current.action && typeof current.action === 'string') {
    const res = sanitizeAndResolveUrl(current.action);
    if (res) return res;
  }

  if (current.dataset) {
    const dataUrl = current.dataset.url || current.dataset.href || current.dataset.link || current.dataset.target || current.dataset.destination;
    if (dataUrl) {
      const res = sanitizeAndResolveUrl(dataUrl);
      if (res) return res;
    }
  }

  const onclickStr = current.getAttribute && current.getAttribute('onclick');
  if (onclickStr) {
    const urlMatch = onclickStr.match(/(https?:\/\/[^\s'"]+|location\.href\s*=\s*['"]([^'"]+)['"]|window\.open\s*\(\s*['"]([^'"]+)['"])/i);
    if (urlMatch) {
      const extracted = urlMatch[2] || urlMatch[3] || urlMatch[1];
      if (extracted) {
        const res = sanitizeAndResolveUrl(extracted);
        if (res) return res;
      }
    }
  }

  const titleAttr = current.getAttribute && (current.getAttribute('title') || current.getAttribute('aria-label'));
  if (titleAttr && titleAttr.match(/https?:\/\/[^\s]+/i)) {
    const matched = titleAttr.match(/https?:\/\/[^\s]+/i)[0];
    const res = sanitizeAndResolveUrl(matched);
    if (res) return res;
  }

  if (current.classList && (current.classList.contains('title') || current.classList.contains('label') || current.tagName === 'SPAN')) {
    const txt = (current.innerText || current.textContent || '').trim().toLowerCase();
    if (txt === 'github') return 'https://github.com';
    if (txt === 'leetcode') return 'https://leetcode.com';
    if (txt === 'chatgpt') return 'https://chatgpt.com';
  }

  return null;
}

function sanitizeAndResolveUrl(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const trimmed = raw.trim();

  if (trimmed.startsWith('javascript:') || trimmed.startsWith('#') || trimmed.startsWith('mailto:') || trimmed.startsWith('tel:')) {
    return null;
  }

  try {
    const resolved = new URL(trimmed, window.location.href);
    return resolved.href;
  } catch (e) {
    if (trimmed.match(/^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}/)) {
      return 'http://' + trimmed;
    }
    return null;
  }
}

/**
 * Calibrated ML Sigmoid Engine with High Weight Impersonation & Typosquatting Protection
 */
function calculateDynamicThreatScore(url) {
  const cleanUrl = url.trim();

  let parsed;
  try {
    parsed = new URL(cleanUrl);
  } catch (e) {
    return { score: 0.95, pct: 95, level: 'HIGH', explanation: 'Malformed URL structure.' };
  }

  const hostname = parsed.hostname.toLowerCase();

  // STEP 1: Verified Official Domain Whitelist (Guaranteed 2% GREEN SAFE)
  const isTrustedDomain = TRUSTED_DOMAINS.some(d => hostname === d || hostname.endsWith('.' + d));

  if (isTrustedDomain) {
    return {
      url: cleanUrl,
      riskScore: 0.02,
      riskPercentage: '2%',
      riskLevel: 'LOW',
      featuresTriggered: [],
      brandImpersonation: null,
      explanation: `[2% Threat Level] Verified official domain (${hostname}). Structural integrity confirmed.`
    };
  }

  // STEP 2: Base Logit Accumulation for Unverified Sites
  let logit = -3.2;
  const triggered = [];
  let brandImpersonation = null;

  const subParts = hostname.split('.');
  const mainDomain = subParts.length >= 2 ? subParts[subParts.length - 2] : hostname;

  // CRITICAL FEATURE 1: Brand Impersonation & Typosquatting Radar (+6.5 HEAVY WEIGHT)
  for (let brand of BRAND_WHITELIST) {
    const isOfficial = brand.domains.some(d => hostname === d || hostname.endsWith('.' + d));
    const mentionsBrand = brand.keywords.some(kw => cleanUrl.toLowerCase().includes(kw));

    // Typosquatting edit distance check (e.g. chattgpt.com vs chatgpt.com, googl.com vs google.com)
    let isTyposquatted = false;
    for (let officialDom of brand.domains) {
      const officialBase = officialDom.split('.')[0];
      const dist = levenshteinDistance(mainDomain, officialBase);
      if (dist >= 1 && dist <= 2 && mainDomain !== officialBase) {
        isTyposquatted = true;
        break;
      }
    }

    if ((mentionsBrand || isTyposquatted) && !isOfficial) {
      logit += 6.5; // Massive heavy weight ensures 96%+ Phishing Threat Score
      brandImpersonation = { 
        targetBrand: brand.name, 
        actualDomain: hostname, 
        officialDomains: brand.domains,
        reason: isTyposquatted ? 'Typosquatting Spelling Trick' : 'Subdomain / Path Impersonation'
      };
      triggered.push({ 
        name: `🚨 BRAND IMPERSONATION (${brand.name})`, 
        impact: 'CRITICAL', 
        desc: `This link attempts to fake ${brand.name}! The actual domain is "${hostname}", NOT official ${brand.domains[0]}.` 
      });
      break;
    }
  }

  // Feature 2: Homoglyph Character Spoofing (+4.5)
  for (let char of hostname) {
    if (HOMOGLYPH_MAP[char]) {
      logit += 4.5;
      triggered.push({ name: 'Homoglyph Character Spoofing', impact: 'CRITICAL', desc: 'Contains non-Latin Cyrillic character visually mimicking ASCII.' });
      break;
    }
  }

  // Feature 3: Raw IP Hostname (+3.8)
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(hostname)) {
    logit += 3.8;
    triggered.push({ name: 'IP Address Hostname', impact: 'HIGH', desc: 'Uses raw IP host instead of domain.' });
  }

  // Feature 4: Suspicious TLD (+3.5)
  const matchedTld = SUSPICIOUS_TLDS.find(tld => hostname.endsWith(tld));
  if (matchedTld) {
    logit += 3.5;
    triggered.push({ name: `High-Risk TLD (${matchedTld})`, impact: 'HIGH', desc: `Statistically over-indexed phishing TLD (${matchedTld}).` });
  }

  // Feature 5: Sensitive Keyword Mismatch (+2.8)
  const sensitiveMatch = SENSITIVE_KEYWORDS.find(kw => cleanUrl.toLowerCase().includes(kw));
  if (sensitiveMatch) {
    logit += 2.8;
    triggered.push({ name: `Sensitive Action ("${sensitiveMatch}")`, impact: 'HIGH', desc: `Requests sensitive action on unverified site.` });
  }

  // Feature 6: Subdomain Depth (>3) (+1.5)
  if (subParts.length > 3) {
    logit += 1.5;
    triggered.push({ name: 'Deep Subdomain Layers', impact: 'MEDIUM', desc: `Uses ${subParts.length - 2} subdomains.` });
  }

  // Sigmoid Calculation
  const probability = 1 / (1 + Math.exp(-logit));
  const percentage = Math.max(1, Math.min(99, Math.round(probability * 100)));

  let riskLevel = 'LOW';
  if (percentage >= 70) riskLevel = 'CRITICAL';
  else if (percentage >= 40) riskLevel = 'HIGH';
  else if (percentage >= 25) riskLevel = 'MODERATE';

  let explanation = `[${percentage}% Threat Level] `;
  if (brandImpersonation) {
    explanation += `🚨 CRITICAL BRAND IMPERSONATION (${brandImpersonation.reason}): Fakes ${brandImpersonation.targetBrand} on domain "${brandImpersonation.actualDomain}". Official site is ${brandImpersonation.officialDomains[0]}.`;
  } else if (triggered.length > 0) {
    explanation += `Evaluated risk signals: ${triggered.map(t => t.name).slice(0, 3).join(', ')}.`;
  } else {
    explanation += `Domain structure passed preliminary security evaluation.`;
  }

  return {
    url: cleanUrl,
    riskScore: parseFloat(probability.toFixed(2)),
    riskPercentage: `${percentage}%`,
    riskLevel: riskLevel,
    featuresTriggered: triggered,
    brandImpersonation: brandImpersonation,
    explanation: explanation
  };
}

/**
 * Mouseover Listener
 */
document.addEventListener('mouseover', (e) => {
  const targetUrl = extractTargetUrlFromEvent(e);
  if (!targetUrl) {
    hideTooltipWithDelay();
    return;
  }

  clearTimeout(hoverTimer);
  lastHoveredUrl = targetUrl;
  hoverTimer = setTimeout(() => {
    inspectAndShowTooltip(targetUrl, e.clientX, e.clientY);
  }, 120);
}, true);

document.addEventListener('mouseout', (e) => {
  const targetUrl = extractTargetUrlFromEvent(e);
  if (targetUrl) {
    hideTooltipWithDelay();
  }
}, true);

async function inspectAndShowTooltip(url, mouseX, mouseY) {
  let report = linkCache.get(url);

  if (!report) {
    report = calculateDynamicThreatScore(url);

    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        chrome.runtime.sendMessage({ action: 'ANALYZE_URL', url: url }, (bgReport) => {
          if (bgReport && bgReport.riskPercentage) {
            linkCache.set(url, bgReport);
            if (lastHoveredUrl === url && currentTooltip) {
              showTooltip(bgReport, mouseX, mouseY);
            }
          }
        });
      } catch (err) {}
    }

    linkCache.set(url, report);
  }

  showTooltip(report, mouseX, mouseY);
}

function showTooltip(report, x, y) {
  removeExistingTooltip();

  const pct = parseInt(report.riskPercentage || '10') || Math.round((report.riskScore || 0) * 100);
  const isCritical = report.riskLevel === 'CRITICAL' || report.riskLevel === 'HIGH' || pct >= 65;
  const isCaution = report.riskLevel === 'MODERATE' || (pct >= 25 && pct < 65);

  let themeColor = '#10b981'; // GREEN (Safe)
  let themeBg = 'rgba(12, 26, 23, 0.95)';
  let statusBadge = `🟢 SAFE LINK (${pct}% Threat Level)`;

  if (isCritical) {
    themeColor = '#f43f5e'; // RED
    themeBg = 'rgba(30, 16, 20, 0.95)';
    statusBadge = `🚨 PHISHING THREAT (${pct}% Threat Level)`;
  } else if (isCaution) {
    themeColor = '#f59e0b'; // AMBER
    themeBg = 'rgba(30, 24, 15, 0.95)';
    statusBadge = `⚠️ CAUTION (${pct}% Threat Level)`;
  }

  const tooltip = document.createElement('div');
  tooltip.id = 'trustlayer-hover-tooltip';

  const posX = Math.min(x + 15, window.innerWidth - 340);
  const posY = Math.min(y + 15, window.innerHeight - 170);

  tooltip.style.cssText = `
    position: fixed;
    top: ${posY}px;
    left: ${posX}px;
    z-index: 2147483647;
    width: 320px;
    padding: 12px 14px;
    border-radius: 10px;
    background: ${themeBg};
    border: 2px solid ${themeColor};
    box-shadow: 0 10px 30px rgba(0,0,0,0.7), 0 0 15px ${themeColor}50;
    color: #ffffff;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12px;
    line-height: 1.4;
    pointer-events: none;
    backdrop-filter: blur(12px);
  `;

  tooltip.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
      <span style="font-weight: 700; color: ${themeColor}; font-size: 12px;">
        ${statusBadge}
      </span>
      <span style="font-size: 9px; color: #94a3b8; font-weight: 700; letter-spacing: 0.5px;">TRUST LAYER</span>
    </div>
    
    <div style="font-size: 11px; margin-bottom: 6px; word-break: break-all; color: #cbd5e1;">
      <code>${report.url}</code>
    </div>

    <p style="margin: 0; color: #e2e8f0; font-size: 11px;">
      ${report.explanation}
    </p>

    ${report.brandImpersonation ? `
      <div style="margin-top: 6px; padding: 6px 8px; background: rgba(244,63,94,0.25); border: 1px solid rgba(244,63,94,0.5); border-radius: 6px; color: #fda4af; font-weight: 600; font-size: 10px;">
        🚨 FAKES ${report.brandImpersonation.targetBrand.toUpperCase()}! (Official: ${report.brandImpersonation.officialDomains[0]})
      </div>
    ` : ''}
  `;

  document.body.appendChild(tooltip);
  currentTooltip = tooltip;
}

let dismissTimer = null;
function hideTooltipWithDelay() {
  clearTimeout(hoverTimer);
  dismissTimer = setTimeout(() => {
    removeExistingTooltip();
  }, 180);
}

function removeExistingTooltip() {
  clearTimeout(dismissTimer);
  const existing = document.getElementById('trustlayer-hover-tooltip');
  if (existing) existing.remove();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.action === 'SHOW_TRUST_BANNER') {
    showTooltip(message.report, window.innerWidth / 2 - 160, 50);
  }
});
